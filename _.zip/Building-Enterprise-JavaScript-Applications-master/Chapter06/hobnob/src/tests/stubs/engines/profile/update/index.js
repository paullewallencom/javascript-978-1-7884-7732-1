import generate, {
  VALIDATION_ERROR_MESSAGE,
  GENERIC_ERROR_MESSAGE
} from '../replace';

export {
  generate as default,
  VALIDATION_ERROR_MESSAGE,
  GENERIC_ERROR_MESSAGE
}

// Same as replace

import validate from './replace';
export default validate;

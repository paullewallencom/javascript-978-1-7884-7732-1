import validate from '../users/create';
export default validate;
